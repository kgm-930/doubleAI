package com.rabu.doubleai.controller;

import com.rabu.doubleai.service.ChatHistoryService;
import com.rabu.doubleai.service.ChatGptService; // 실제 챗봇 로직 서비스
import com.rabu.doubleai.model.ChatRequest; // 요청 객체
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ChatController {

    private final ChatHistoryService chatHistoryService;
    private final ChatGptService chatGptService; // 챗봇 서비스

    public ChatController(ChatHistoryService chatHistoryService, ChatGptService chatGptService) {
        this.chatHistoryService = chatHistoryService;
        this.chatGptService = chatGptService;
    }

    @PostMapping("/chat")
    public String chat(@RequestBody ChatRequest chatRequest) {
        String question = chatRequest.getQuestion();
        String username = chatRequest.getUsername();

        // ChatGptService에서 답변을 가져옴
        String answer = chatGptService.getChatGptResponse(question);

        // 대화 기록 저장
        chatHistoryService.saveChatHistory(username, question, answer);

        return answer; // 챗봇 응답 반환
    }
}
