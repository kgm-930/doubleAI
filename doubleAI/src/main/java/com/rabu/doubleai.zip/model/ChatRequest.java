package com.rabu.doubleai.model;

public class ChatRequest {
    private String question;
    private String username;

    // 기본 생성자, 게터와 세터 추가
    public ChatRequest() {}

    public ChatRequest(String question, String username) {
        this.question = question;
        this.username = username;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
